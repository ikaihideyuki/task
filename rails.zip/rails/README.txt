[所要時間]
・ruby、またはrailsの学習　⇒　8h
・環境構築　⇒　1h
・form処理の実装　⇒　2h
・model（webapi処理）の実装　⇒　1h
・登録金融機関一覧、登録金融機関の残高の出力処理　⇒　1h

計13h

※rubyが初めて触る言語でしたので、言語またはフレームワークの学習に時間がかかりました
※工夫した点は、webapiでのデータ取得処理をmodelで実装し、汎用的にcontrollerで呼び出せるようにしたところです。

[確認用URL]
http://localhost:3000/user_banks/index

[参考URL]
https://sakurawi.hateblo.jp/entry/form-validation
https://www.javadrive.jp/rails/
https://qiita.com/seisonshi/items/c23c0154c45ccbfa9999
など
